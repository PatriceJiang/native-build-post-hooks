module.exports = {
    title: '原生构建后置钩子',
    description: 'after-build 回调至脚本 hooks/after-build(.bat|.sh).',
};
