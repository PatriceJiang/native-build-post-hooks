module.exports = {
    title: 'Native Build Post Hook',
    description: 'Add hooks/after-build(.bat|.sh) script for after-build callbacks.',
};
